import{_ as e,o as c,c as t}from"./index-d1f51339.js";const o={};function r(n,s){return c(),t("div")}const a=e(o,[["render",r]]);export{a as default};
