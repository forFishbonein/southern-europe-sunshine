import{G as o,M as r,o as n,l as c}from"./index-c7682cff.js";const t={};function s(_,a){const e=r("router-view");return n(),c(e)}const p=o(t,[["render",s]]);export{p as default};
