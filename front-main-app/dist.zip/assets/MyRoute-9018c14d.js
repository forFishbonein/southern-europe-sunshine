import{_ as e}from"./index-5dab0b64.js";const r={};function t(c,n){return null}const o=e(r,[["render",t]]);export{o as default};
