import{_ as e,o as c,c as n}from"./index-5dab0b64.js";const o={};function r(t,a){return c(),n("div")}const _=e(o,[["render",r]]);export{_ as default};
