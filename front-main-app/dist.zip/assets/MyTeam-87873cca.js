import{G as e,o as c,j as o}from"./index-c7682cff.js";const r={};function t(n,a){return c(),o("div")}const _=e(r,[["render",t]]);export{_ as default};
