import{_ as o,i as r,o as n,J as c}from"./index-2d6b4af9.js";const t={};function s(_,a){const e=r("router-view");return n(),c(e)}const i=o(t,[["render",s]]);export{i as default};
