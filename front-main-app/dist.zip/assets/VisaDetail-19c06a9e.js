import{_ as e,o as c,c as t}from"./index-2d6b4af9.js";const o={};function r(a,n){return c(),t("div")}const _=e(o,[["render",r]]);export{_ as default};
