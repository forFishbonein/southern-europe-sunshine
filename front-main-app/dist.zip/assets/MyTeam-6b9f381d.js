import{_ as e,o as c,c as o}from"./index-2d6b4af9.js";const r={};function t(n,a){return c(),o("div")}const _=e(r,[["render",t]]);export{_ as default};
