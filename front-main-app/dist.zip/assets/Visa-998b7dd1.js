import{_ as o,g as r,o as t,v as c}from"./index-437a5076.js";const n={};function s(_,a){const e=r("router-view");return t(),c(e)}const i=o(n,[["render",s]]);export{i as default};
