import{_ as o,f as r,o as n,s as c}from"./index-86c923c6.js";const t={};function s(_,a){const e=r("router-view");return n(),c(e)}const p=o(t,[["render",s]]);export{p as default};
