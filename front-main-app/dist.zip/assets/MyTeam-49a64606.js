import{_ as e,o as c,c as o}from"./index-5dab0b64.js";const r={};function t(n,a){return c(),o("div")}const _=e(r,[["render",t]]);export{_ as default};
