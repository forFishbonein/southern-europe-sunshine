import{_ as e,o as c,c as r}from"./index-2d6b4af9.js";const t={};function o(n,a){return c(),r("div")}const _=e(t,[["render",o]]);export{_ as default};
