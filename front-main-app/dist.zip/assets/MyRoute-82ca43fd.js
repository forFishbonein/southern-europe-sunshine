import{_ as e}from"./index-d1f51339.js";const r={};function t(c,n){return null}const o=e(r,[["render",t]]);export{o as default};
