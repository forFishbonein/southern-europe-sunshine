import{_ as o,i as r,o as t,J as c}from"./index-d1f51339.js";const n={};function s(_,a){const e=r("router-view");return t(),c(e)}const f=o(n,[["render",s]]);export{f as default};
