import{G as o,M as r,o as t,l as c}from"./index-c7682cff.js";const n={};function s(_,a){const e=r("router-view");return t(),c(e)}const i=o(n,[["render",s]]);export{i as default};
