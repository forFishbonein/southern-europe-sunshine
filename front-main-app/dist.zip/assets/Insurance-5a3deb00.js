import{_ as o,i as r,o as n,J as c}from"./index-5dab0b64.js";const t={};function s(_,a){const e=r("router-view");return n(),c(e)}const i=o(t,[["render",s]]);export{i as default};
