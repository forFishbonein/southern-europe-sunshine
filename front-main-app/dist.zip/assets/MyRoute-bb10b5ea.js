import{_ as e}from"./index-2d6b4af9.js";const r={};function t(c,n){return null}const o=e(r,[["render",t]]);export{o as default};
