import{G as e,o as c,j as n}from"./index-c7682cff.js";const o={};function r(t,a){return c(),n("div")}const _=e(o,[["render",r]]);export{_ as default};
