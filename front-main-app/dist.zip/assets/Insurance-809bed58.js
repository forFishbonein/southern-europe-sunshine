import{_ as o,g as r,o as n,v as c}from"./index-3b6e501c.js";const t={};function s(_,a){const e=r("router-view");return n(),c(e)}const p=o(t,[["render",s]]);export{p as default};
