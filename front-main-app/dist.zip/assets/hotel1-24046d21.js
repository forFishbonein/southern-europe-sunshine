const e=""+new URL("../images/hotel1.jpg",import.meta.url).href;export{e as _};
