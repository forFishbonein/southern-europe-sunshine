import{G as e,o as c,j as r}from"./index-c7682cff.js";const t={};function o(n,a){return c(),r("div")}const _=e(t,[["render",o]]);export{_ as default};
