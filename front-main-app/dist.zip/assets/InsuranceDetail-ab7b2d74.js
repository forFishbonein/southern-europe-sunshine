import{_ as e,o as c,c as n}from"./index-5dab0b64.js";const r={};function t(o,a){return c(),n("div")}const _=e(r,[["render",t]]);export{_ as default};
