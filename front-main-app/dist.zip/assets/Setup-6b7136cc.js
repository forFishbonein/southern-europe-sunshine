import{_ as e,o as c,c as t}from"./index-5dab0b64.js";const o={};function r(n,s){return c(),t("div")}const a=e(o,[["render",r]]);export{a as default};
